import React from "react";
import Company from "./Company";
export default function index() {
  return (
    <>
      <Company />
    </>
  );
}
