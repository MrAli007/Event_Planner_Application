import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../../../../context/AuthContext";
import { motion } from "framer-motion";
import saylani from "../../../../images/saylani.png";
import "../../../../scss/navbar.scss";
export default function Navbar() {
  const { isAuthenticated, dispatch } = useContext(AuthContext);
  const handleLogout = () => {
    dispatch({ type: "LOGOUT" });
    alert("logged out");
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-primary navbar-dark">
        <div className="container-fluid">
          <Link to="/" className="navbar-brand">
            <img className="image" src={saylani} alt="" />
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse "
            id="navbarSupportedContent"
          >
            <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
              <motion.li whileTap={{ scale: 1.2 }} className="nav-item">
                <Link to="/" className="nav-link active">
                  Home
                </Link>
              </motion.li>
              <motion.li whileTap={{ scale: 1.2 }} className="nav-item">
                <Link to="/about" className="nav-link">
                  About
                </Link>
              </motion.li>
              <motion.li whileTap={{ scale: 1.2 }} className="nav-item">
                <Link to="/events" className="nav-link">
                  Events
                </Link>
              </motion.li>

              <motion.li whileTap={{ scale: 1.2 }} className="nav-item">
                <Link to="/contact" className="nav-link">
                  Contact
                </Link>
              </motion.li>
            </ul>
            <div className="d-flex">
              {!isAuthenticated ? (
                <Link
                  to="/authentication/login"
                  className="btn btn-success text-white"
                >
                  Login
                </Link>
              ) : (
                <>
                  <Link
                    to="/dashboard"
                    className="btn btn-info btn-sm me-2 text-white"
                  >
                    Create Event
                  </Link>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={handleLogout}
                  >
                    Logout
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}
