import React from "react";
import "../../../../scss/eventcard.scss";

function EventCard(props) {
  return (
    <div className="card-container">
      <div className="card mt-3">
        <div className="card-body">
          <h2>{props.title}</h2>
          <p>Creator: {props.creator}</p>
          <p>Location:{props.location}</p>
          <p>Date: {props.date}</p>
          <p>Time: {props.time}</p>
        </div>
      </div>
      <button
        type="button"
        className="btn btn-info btn-sm me-1"
        data-bs-toggle="modal"
        data-bs-target="#editModal"
        // onClick={() => {
        //   setTodo(todo);
        // }}
      >
        "Edit"
      </button>
    </div>
  );
}

export default EventCard;
