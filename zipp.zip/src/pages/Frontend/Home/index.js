import React from "react";
import Hero from "./Hero";

export default function index() {
  return (
    <>
      <Hero />
    </>
  );
}
